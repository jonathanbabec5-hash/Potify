# POTIFY: A Wonderful High Life — Public Game Devlog

This folder is a standalone, searchable public showcase of the project's creative design registry.

- **index.html**: offline-friendly, browsable feature catalog of 469 concepts with 18 categories and honest status badges.
- **POTIFY_CITY_PUBLIC_WORLD_BIBLE.md**: long-form public design bible.
- **POTIFY_CITY_REGISTRY_PUBLIC.json**: machine-readable spoiler-safe register.
- **CHANGELOG.md**: changelog, never a replacement for testing.

## Publish to GitHub Pages

1. Create a new *public* GitHub repository, without a license selected by default.
2. Upload the four files in this folder to the repository root.
3. In GitHub repository Settings → Pages, set Source to **Deploy from a branch** and choose `main` / `(root)`.
4. Save, wait for GitHub to publish, and check the URL shown in Pages.
5. Future changes: update the registry, rebuild `index.html`, publish the changelog and screenshots of *actual tested game* only.

No feature in this design registry is asserted to be an independently verified released game feature. Secret answers, keys, and internal book material are never included in the public package.

This public design registry is not a license grant for game artwork, story, or brand. If inviting outside contributions, define license/assignment terms before including proposed external creative assets.
