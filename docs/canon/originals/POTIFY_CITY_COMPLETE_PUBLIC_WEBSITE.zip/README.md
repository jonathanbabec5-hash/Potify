# POTIFY City — repaired complete public master key

Open **index.html**. All 469 entries are embedded, searchable and shareable through permanent #ENTRY-ID anchors. The full public master PDF, Markdown, JSON, CSV and changelog are linked by relative paths and included in this folder. No network, backend or external asset is required to browse the key.

The private owner edition is distributed separately; do not upload it to a public repository.

**Status note:** This is a design registry, not proof of playable implementation. 
